import sys
import json
import requests
from main_types import main_types
from secrets import secrets


def getData(query, offset=0, page_size=100, local_type=[]):
    url = "https://api.os.uk/search/names/v1/find"
    params = {'key': secrets['key'], 'query': query,
              'maxresults': page_size, 'offset': offset}
    if local_type:
        lt2 = []
        for lt in local_type:
            lt2.append("LOCAL_TYPE:" + lt)
        params['fq'] = ' '.join(lt2)

    response = requests.get(url, params=params)
    res = []
    more = False
    if response.status_code == 200:
        results = json.loads(response.content)
        total = results['header']['totalresults']

        for result in results['results']:
            entry = result['GAZETTEER_ENTRY']
            res.append(entry)
        if total > offset + page_size:
            more = True
        return (more, res)
    else:
        print(response.status_code)
        print(response.text)
        print(response.url)
        sys.exit(2)


def runQuery(query, local_type=[], mtype=None):
    data = []
    more = True
    offset = 0
    page_size = 100
    if mtype:
        if mtype not in main_types:
            keys = ', '.join([k for k in main_types.keys()])
            print(f"Unknown type {mtype} expected one of {keys}")
            sys.exit(23)
        local_type += main_types[mtype]
    while more:
        more, res = getData(query, offset, page_size, local_type)
        data += res
        offset += page_size

    return data


# places = runQuery("Southampton")
# print(len(places))
# print(places[0])

places = runQuery("Glasgow", mtype='populatedPlace')
print(len(places))
print(places[0])
print("-----" * 10)
places = runQuery("Glasgow", mtype='PopulatedPlace')
